#!/bin/bash
cd ~/OGG181_WHKSHP/Lab6/Build
./start_swingbench_181.sh &
./start_swingbench_182.sh &
