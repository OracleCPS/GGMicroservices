
insert into soe.logon values ('48092713',130159,sysdate);
insert into soe.logon values ('48092714',130160,sysdate);
insert into soe.logon values ('48092715',130161,sysdate);
commit;