use amea;
select count(*) as account from amea.account;
select count(*) as account_trans from amea.account_trans;
select count(*) as teller_trans from amea.teller_trans;
select count(*) as branch_atm from amea.branch_atm;
select count(*) as branch from amea.branch;
select count(*) as teller from amea.teller;
select count(*) as trans_type from amea.trans_type;
