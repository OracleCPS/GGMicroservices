set echo on;
select count(*) from ACCOUNT;
select count(*) from ACCOUNT_TRANS;
select count(*) from TELLER_TRANS; 
select count(*) from BRANCH_ATM;
select count(*) from BRANCH;
select count(*) from TELLER;
select count(*) from TRANS_TYPE;

